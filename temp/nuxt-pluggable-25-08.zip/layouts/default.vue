
<template>
  <main>
    <Navbar />   
    <slot />
  </main>
</template> 