<template>
  <NuxtLayout class="content" name="logged" >
    <div class="max-w-sm mx-auto mt-4">
        Home
    </div>
  </NuxtLayout>
</template>
